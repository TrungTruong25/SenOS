#!/bin/sh
# Firmware gốc chạy file này ngay sau trimui/app/MainUI và xem mã thoát:
#   0 = giao diện trên thẻ đã chạy xong  -> không mở MainUI gốc
#   1 = chưa chạy                        -> mở MainUI gốc (giao diện TrimUI)
if [ -f /tmp/senos_ok ]; then
	rm -f /tmp/senos_ok
	exit 0
fi
exit 1
