#!/bin/sh
# Hệ máy dựng sẵn của SenOS: chạy bằng senplay với core mednafen_pce_fast.
exec sh "$(dirname "$0")/../../scripts/play.sh" PCE mednafen_pce_fast "$1"
