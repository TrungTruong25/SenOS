#!/bin/sh
# Hệ máy dựng sẵn của SenOS: chạy bằng senplay với core fceumm.
exec sh "$(dirname "$0")/../../scripts/play.sh" FC fceumm "$1"
