#!/bin/sh
# Hệ máy dựng sẵn của SenOS: chạy bằng senplay với core melonds.
exec sh "$(dirname "$0")/../../scripts/play.sh" NDS melonds "$1"
