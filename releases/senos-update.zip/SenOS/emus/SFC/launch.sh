#!/bin/sh
# Hệ máy dựng sẵn của SenOS: chạy bằng senplay với core snes9x2005_plus.
exec sh "$(dirname "$0")/../../scripts/play.sh" SFC snes9x2005_plus "$1"
