#!/bin/sh
# Hệ máy dựng sẵn của SenOS: chạy bằng senplay với core gambatte.
exec sh "$(dirname "$0")/../../scripts/play.sh" GB gambatte "$1"
