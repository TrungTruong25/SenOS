#!/bin/sh
# Hệ máy dựng sẵn của SenOS: chạy bằng senplay với core pcsx_rearmed.
exec sh "$(dirname "$0")/../../scripts/play.sh" PS pcsx_rearmed "$1"
