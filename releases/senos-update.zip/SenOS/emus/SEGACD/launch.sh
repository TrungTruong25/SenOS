#!/bin/sh
# Hệ máy dựng sẵn của SenOS: chạy bằng senplay với core genesis_plus_gx.
exec sh "$(dirname "$0")/../../scripts/play.sh" SEGACD genesis_plus_gx "$1"
