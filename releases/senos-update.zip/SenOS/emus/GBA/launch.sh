#!/bin/sh
# Hệ máy dựng sẵn của SenOS: chạy bằng senplay với core gpsp.
exec sh "$(dirname "$0")/../../scripts/play.sh" GBA gpsp "$1"
