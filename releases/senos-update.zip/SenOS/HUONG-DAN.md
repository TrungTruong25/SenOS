# SenOS 0.5.2 — hệ thống cho TrimUI Brick Pro (TG4040)

SenOS chạy từ thẻ nhớ, trên kernel và driver của firmware gốc có sẵn trong máy. Từ bản 0.4.0, giống
cách làm của MinUI/NextUI, SenOS **tự mang theo trình chạy game và các core giả lập của riêng nó**:
thẻ nhớ không cần cài gói nào của TrimUI. SenOS không ghi gì vào bộ nhớ trong của máy.

> Giao diện, cài đặt và phần chạy game cũ (0.1.0) đã được người dùng chạy trên Brick Pro thật.
> Các phần thêm sau đó — Bluetooth, hiệu chỉnh cần analog (0.2.0), bộ tải qua WiFi (0.3.x), và
> **trình chạy game mới cùng các core đi kèm (0.4.0)** — mới chỉ được thử bằng giả lập ARM64 trên
> máy tính, chưa thử trên máy thật.

## Cài trên thẻ trắng

1. Định dạng thẻ nhớ FAT32 hoặc exFAT.
2. Giải nén `SenOS-0.5.0.zip` vào gốc thẻ. Phải có `SenOS/` và `trimui/app/MainUI`.
3. Lắp thẻ, bật máy. SenOS tự tạo thư mục `Roms/<hệ máy>` và `Bios`.
4. Chép game vào đúng thư mục (rút thẻ ra máy tính, hoặc Ứng dụng → Truyền file qua WiFi).

## Hệ máy có sẵn

| Thư mục game | Hệ máy | Core | Đuôi file |
|---|---|---|---|
| `Roms/FC` | Nintendo (NES / Famicom) | fceumm | nes, fds, unf, zip |
| `Roms/GB`, `Roms/GBC` | Game Boy, Game Boy Color | gambatte | gb, gbc, zip |
| `Roms/GBA` | Game Boy Advance | gpSP | gba, zip |
| `Roms/SFC` | Super Nintendo | snes9x2005 plus | sfc, smc, zip |
| `Roms/MD`, `Roms/MS`, `Roms/GG` | Mega Drive, Master System, Game Gear | Genesis Plus GX | md, gen, bin, sms, gg, zip |
| `Roms/SEGACD` | Sega CD (cần BIOS) | Genesis Plus GX | cue, chd, iso |
| `Roms/PS` | PlayStation | PCSX-ReARMed | cue, chd, pbp, m3u, iso |
| `Roms/PCE` | PC Engine / TurboGrafx-16 | Beetle PCE Fast | pce, sgx, cue, chd, zip |
| `Roms/NDS` | Nintendo DS (mới ở 0.4.1) | melonDS | nds |

Thư mục đặt tên kiểu NextUI/MinUI như `Roms/Game Boy Advance (GBA)` cũng được nhận.
Game nén `.zip` được giải nén tạm vào RAM khi chơi. File `.7z` chưa hỗ trợ.

### Nintendo DS

- Hai màn hình hiện chồng dọc ở giữa (mỗi màn hình phóng 2 lần). Đổi bố cục trong lúc chơi:
  MENU → Tùy chọn giả lập → Screen Layout (trên/dưới, trái/phải, chỉ một màn hình, hoặc Hybrid: một
  màn hình to kèm màn hình nhỏ).
- Máy không có màn hình cảm ứng: **cần phải** di chuyển con trỏ, **nhấn cần phải (R3)** để chạm.
  **R2** đổi vị trí hai màn hình, **L3** gập/mở máy, **L2** thổi vào micro.
- Không cần BIOS (melonDS dùng BIOS mã mở đi kèm). File `.nds` để nguyên, không nén zip.
- Tốc độ: melonDS là giả lập mã nguồn mở, nặng hơn nhiều so với DraStic (giả lập đóng mà các firmware
  khác dùng). Trên chip của Brick Pro, nhiều game — nhất là game 3D — có thể chạy chậm hơn tốc độ thật.
  SenOS tự cho CPU chạy hết công suất khi chơi NDS. Nếu cần nhanh hơn, dùng DraStic: khi thẻ có
  `Emus/NDS`, SenOS tự dùng cái đó thay cho melonDS.
- **Advanced DraStic** (bản của trngaje, như spruceOS dùng cho Brick Pro) đặt trong `Emus/NDS/advdrastic`,
  chạy bằng `Emus/NDS/launch_adv.sh`. Có nhiều kiểu bố trí cho màn 1024×768, gồm cả toàn màn hình:
  **SELECT + trái/phải** đổi kiểu bố trí, **MENU** mở menu, **R2** đổi màn trên/dưới, **L2** chuyển
  bút cảm ứng / D-pad, **SELECT + L / R** nạp / lưu nhanh, **SELECT + START** thoát. DraStic gốc của TrimUI
  vẫn chọn được (SELECT trên game → Chạy bằng core, hoặc Tùy chọn hệ máy).

**BIOS**: chép vào thư mục `Bios` ở gốc thẻ, đúng tên file. PlayStation chạy được không cần BIOS
(dùng BIOS mô phỏng) nhưng có `scph5501.bin` thì tương thích hơn; Sega CD bắt buộc `bios_CD_U.bin`
/ `bios_CD_E.bin` / `bios_CD_J.bin`; game CD của PC Engine cần `syscard3.pce`.

**File lưu**: `Saves/SenOS/<hệ máy>/` (save trong game `.srm`) và `Saves/SenOS/<hệ máy>/states/`.

## Nút trong lúc chơi

| Nút | Chức năng |
|---|---|
| MENU | Mở menu: Tiếp tục, Lưu / Nạp trạng thái (8 ô), Tua nhanh, Khung hình, Tùy chọn giả lập, Chơi lại, Lưu và thoát |
| MENU + R1 / L1 | Lưu nhanh / nạp nhanh vào ô đang chọn |
| MENU + R2 | Bật / tắt tua nhanh |
| MENU + Âm lượng +/− | Tăng / giảm độ sáng |
| Âm lượng +/− | Âm lượng (giữ để chỉnh liên tục) |
| Nhấn nhanh nút Home | Mở menu trong game (như MENU) |
| Giữ nút Home 1 giây | Lưu và thoát về SenOS |
| Nhấn nhanh nút nguồn | Ngủ |
| Giữ nút nguồn 1 giây | Lưu rồi tắt máy |

Thoát game là tự lưu; mở lại game đó sẽ vào đúng chỗ đang chơi (tắt được ở Cài đặt → Tiếp tục nhanh).
Tùy chọn riêng của từng core đổi ngay trong game (MENU → Tùy chọn giả lập) và được nhớ lại trong
`SenOS/config/cores/<tên core>.opt`.

## PortMaster

Ứng dụng → **Cài PortMaster** tải gói PortMaster chính thức (`trimui.portmaster.zip`) và lớp tương thích
TRIMUI_EX cho Brick Pro, rồi yêu cầu khởi động lại; lần bật máy đó bộ cài của TRIMUI_EX tự hoàn tất.
Sau đó PortMaster nằm trong danh sách Ứng dụng, game cài xong nằm ở hệ máy Ports.

**Game cài xong mà không hiện (sửa ở 0.4.3).** PortMaster để game trong `Data/ports` rồi phải chép
script mở game sang `Roms/PORTS`. Bản PortMaster hiện tại có lỗi ở bước chép này trên máy TrimUI: nó
văng ra ngay sau khi cài, nên game chỉ nằm trong `Data/ports` (firmware gốc cũng gặp). Từ 0.4.3:

- Mỗi lần mở giao diện, SenOS tự chép các script còn thiếu từ `Data/ports` sang `Roms/PORTS`, kèm ảnh
  bìa sang `Imgs/PORTS`. Game cài từ trước cũng hiện lại. Script bạn tự sửa trong `Roms/PORTS` không
  bị ghi đè; SenOS không xóa gì — gỡ game thì dùng PortMaster.
- SenOS sửa đúng một dòng lỗi trong PortMaster
  (`Apps/PortMaster/PortMaster/pylibs/harbourmaster/platform.py`) để nó không văng nữa. Bản gốc được
  lưu trong `System/backups/portmaster/`. Khi PortMaster tự cập nhật, SenOS sửa lại ở lần mở kế tiếp.
- Thoát PortMaster là game mới hiện ngay ở hệ máy PORTS, không cần khởi động lại.

Lưu ý: PortMaster và TRIMUI_EX là phần mềm của bên thứ ba, không nằm trong gói SenOS. Bộ cài của
TRIMUI_EX có ghi vài file vào bộ nhớ trong của máy (`/bin/bash`…, có sao lưu bản gốc). Làm tay cũng
được: giải nén `TRIMUI_EX.zip` (github.com/deni12345/TRIMUI_EX) vào gốc thẻ, đặt nguyên file
`trimui.portmaster.zip` ở gốc thẻ, rồi khởi động lại.

## Thêm giả lập khác (tùy chọn)

SenOS vẫn đọc định dạng `Emus/<hệ máy>/config.json` của thẻ gốc. Nếu trên thẻ có sẵn giả lập cho một hệ
máy trong `Emus/` thì SenOS dùng cái đó thay cho core dựng sẵn. Mục Ứng dụng → "Cài thêm bộ giả lập của
TrimUI" tải gói của TrimUI (RetroArch, thêm nhiều hệ máy như N64, PSP, arcade); mục này không bắt buộc.

## Cài lên thẻ đang dùng

1. Thẻ đang dùng trên máy vẫn dùng tiếp được: SenOS dùng lại game trong `Roms/`, và nếu thẻ có sẵn
   `Emus`, `Apps`, `RetroArch` thì các giả lập, PortMaster ở đó vẫn chạy như trước.
2. Sao lưu thẻ nhớ ra máy tính.
3. Nếu ở gốc thẻ đã có thư mục `trimui` (do CrossMix hoặc firmware tùy biến khác tạo ra),
   hãy đổi tên nó thành `trimui.bak` trước — hai hệ thống không dùng chung được.
4. Giải nén `SenOS-0.5.0.zip` vào **gốc thẻ nhớ**. Sau khi giải nén phải có:
   - `SenOS/` (chương trình, script, cài đặt)
   - `trimui/app/MainUI` và `trimui/app/preload.sh` (điểm móc khởi động)
5. Lắp thẻ vào máy và bật máy. SenOS sẽ hiện thay cho giao diện gốc.

## Điều khiển

| Nút | Chức năng |
|---|---|
| D-pad / cần trái | Di chuyển. Ở trang chủ: trái/phải chọn game; ở thẻ Thư viện / Ứng dụng: bốn hướng trong lưới |
| A / B | Chọn / Quay lại (đổi được trong Cài đặt → Điều khiển) |
| L1 / R1 | Trang chủ: đổi thẻ (Gần đây · Yêu thích · Thư viện · Ứng dụng). Lưới game: lật trang |
| X | Đánh dấu yêu thích |
| Y | Tìm game |
| SELECT | Trên một game: tùy chọn của game (yêu thích, xóa game) và của hệ máy. Ở dải Chơi gần đây: bỏ game khỏi danh sách |
| MENU hoặc START | Menu chính (trượt từ trái): Trang chủ, Thư viện, Yêu thích, Ứng dụng, Tìm game, Truyền file, Cài đặt, Nguồn |
| Giữ nút nguồn | Menu nguồn: ngủ, tắt máy, khởi động lại, về giao diện gốc |
| Âm lượng +/− | Âm lượng, có thanh hiển thị mức |
| MENU + Âm lượng +/− | Độ sáng màn hình |
| Nút Home | Bảng truy cập nhanh (trượt từ phải): bật/tắt WiFi, Bluetooth, xung CPU, nhiệt độ, RAM, chế độ CPU khi chơi, độ sáng, âm lượng, đèn LED, ngủ/tắt máy. Nhấn Home lần nữa hoặc B để đóng |
| Công tắc gạt | Tắt tiếng (mặc định). Đổi thành tắt đèn LED hoặc không làm gì ở Cài đặt → Điều khiển |

Nút Home và công tắc gạt dùng được cả khi đang chơi. Với game chạy bằng RetroArch, nhấn Home mở
menu RetroArch, giữ Home thì lưu và thoát. Port PortMaster và ứng dụng không thoát bằng Home được
(chúng có cách thoát riêng), nhưng nút âm lượng và công tắc vẫn hoạt động.

## Chức năng

- **Thư viện game**: đọc `Emus/*/config.json` và `Roms/` theo đúng định dạng thẻ gốc; game
  vừa chơi, thời gian chơi, yêu thích, tìm kiếm, ảnh bìa (`Imgs/<hệ máy>/<tên rom>.png`).
- **Ứng dụng & Ports**: mọi thứ trong `Apps/` (PortMaster, trình quản lý file…) và hệ máy
  `PORTS` hiện ra như trên giao diện gốc.
- **Tiếp tục nhanh**: tự mở lại game đang chơi khi bật máy; thoát game là tự lưu, mở lại là chơi
  tiếp đúng chỗ; giữ nút nguồn 1 giây khi đang chơi để lưu rồi tắt máy; tự lưu và tắt khi pin dưới 3%.
- **WiFi**: bật/tắt, quét mạng, nhập mật khẩu bằng bàn phím trên màn hình.
  - Từ 0.4.2 máy **tự bật WiFi và nối lại mạng đã lưu** mỗi lần bật máy và mỗi lần thoát game về
    giao diện. Đang ở giao diện mà rớt mạng thì khoảng một phút máy tự thử nối lại.
  - Mạng đã nối được một lần sẽ có chữ “Đã lưu”. Chọn mạng đó để nối lại không cần gõ mật khẩu,
    nhập mật khẩu mới, hoặc “Quên mạng này”.
  - Tắt WiFi trong màn hình này thì máy nhớ là bạn đã tắt và không tự bật lại nữa (đỡ tốn pin).
  - Danh sách mạng đã lưu nằm trong bộ nhớ trong của máy (`/etc/wifi/wpa_supplicant.conf`, kèm một
    bản sao ở `/mnt/UDISK/senos-wifi.conf`), không nằm trên thẻ nhớ.
  - Nếu máy vẫn không tự nối: xem dòng “wifi lúc bật máy: …” trong `SenOS/logs/senos.log`.
- **Bluetooth** (mới ở 0.2.0): bật/tắt, quét, ghép nối, kết nối lại, quên thiết bị. Tay cầm là
  trường hợp chính. Phát âm thanh qua tai nghe Bluetooth là mục *thử nghiệm*, mặc định tắt;
  nếu bật mà game mất tiếng thì tắt mục đó đi là âm thanh về loa máy.
- **Truyền file qua WiFi**: mở Ứng dụng → Truyền file, rồi dùng trình duyệt trên điện
  thoại/máy tính (cùng mạng) vào địa chỉ hiện trên màn hình và nhập mã PIN. Máy chủ chỉ
  chạy trong lúc màn hình này mở.
  - **Gửi cả thư mục (mới ở 0.4.4)**: bấm “Gửi cả thư mục…” hoặc kéo-thả thư mục vào trang. Thư mục
    con được giữ nguyên, mỗi thư mục hiện một dòng tiến độ chung. Nút chọn thư mục của trình duyệt
    không gửi được thư mục rỗng; kéo-thả thì có.
  - **Điện thoại không chọn được thư mục**: nén thư mục thành file `.zip`, gửi lên, rồi bấm “Giải nén”
    ở dòng của file đó. Zip chỉ có một thư mục bên trong thì thư mục ấy nằm ngay cạnh file zip; nếu
    không, nội dung vào thư mục mang tên file zip.
  - **Lấy cả thư mục về máy tính**: bấm “Tải .zip” ở dòng của thư mục (ví dụ `Saves` để sao lưu save).
  - **Tải game từ link (mới ở 0.5.4)**: mở mục “🌐 Tải game từ link” trên trang web, dán link file
    (mỗi dòng một link: Google Drive, Dropbox, GitHub, NAS, trang web…) rồi bấm “Tải về máy”. Máy tự
    tải thẳng từ Internet về thẻ, không đi qua điện thoại.
    - “Lưu vào: Tự chọn theo loại game” đặt file vào `Roms/<hệ máy>` theo đuôi (.gba → GBA, .nds → NDS…);
      không đoán được thì vào `Roms/_Tai ve`. Hoặc chọn hẳn một hệ máy / thư mục đang mở.
    - File .zip/.7z được tự giải nén (bỏ chọn nếu không muốn); game arcade (MAME, FBNeo, CPS, Neo Geo,
      PGM…) luôn giữ nguyên file .zip. Nút “Giải nén” trong danh sách giờ nhận cả .7z.
    - Link Google Drive: đặt chia sẻ “Bất kỳ ai có đường liên kết”; link thư mục Drive không dùng được.
    - Màn hình máy hiện tên file, phần trăm và tốc độ. Giữ màn hình Truyền file mở cho đến khi tải xong;
      thoát ra là các link đang tải bị dừng.
  - **File trùng tên (mới ở 0.5.3)**: trước khi gửi, trang web hỏi thẻ xem file nào đã có và hiện
    hộp chọn: *Ghi đè tất cả*, *Chỉ ghi đè file khác dung lượng*, *Bỏ qua file trùng*, *Giữ cả hai*
    (file mới thành “tên (1)”) hoặc *Hủy*. Ô “Khi trùng tên” trên thanh công cụ để chọn sẵn, khỏi hỏi lại.
  - **Nhanh hơn (0.5.3)**: trong lúc màn hình Truyền file mở, máy tắt chế độ tiết kiệm điện của WiFi và
    cho CPU chạy hết tốc độ (đóng màn hình là trả lại như cũ); file nhỏ gửi song song 3 file một lúc,
    file lớn ghi xuống thẻ theo khối 1 MB. Dòng tiến độ có hiện tốc độ MB/s.
  - Không ghi được vào `SenOS/bin`, `SenOS/scripts` và `trimui/` qua trang web, kể cả bằng thư mục hay zip.
- **Tải ảnh bìa** tự động từ kho libretro-thumbnails; **đồng bộ giờ** qua mạng.
- **Phần cứng**: độ sáng, âm lượng, đèn LED RGB (màu, hiệu ứng, tốc độ), hồ sơ CPU khi chơi,
  tự ngủ, thông tin pin và nhiệt độ, xoay màn hình.
- **Điều khiển**: hiệu chỉnh cần analog (mới ở 0.2.0), kiểm tra nút, gán lại nút, đổi A/B.
- **Quản lý game** (mới ở 0.2.0): xóa game khỏi thẻ ngay trên máy, bỏ game khỏi danh sách Tiếp tục.
- **Hệ thống**: ngôn ngữ Việt/Anh, màu giao diện, múi giờ, đặt ngày giờ thủ công, báo cáo
  chẩn đoán, cập nhật.

### Hiệu chỉnh cần analog

Cài đặt → Điều khiển → Hiệu chỉnh cần analog. Với mỗi cần: xoay thật rộng 8 giây, rồi thả tay
4 giây. SenOS ghi kết quả vào `/mnt/UDISK/joypad.config` và `joypad_right.config` (đúng hai file
mà firmware gốc dùng). Nếu số đo vô lý, bạn bấm B để hủy, hoặc máy mất nguồn giữa chừng, hiệu
chỉnh cũ được trả lại.

## Nếu có trục trặc

- **Màn hình đen hoặc nút không ăn**: cứ tắt/bật máy. Sau 3 lần bật máy liên tiếp mà SenOS
  không nhận được nút bấm nào, lần kế tiếp máy tự dùng giao diện gốc.
- **Tắt tạm SenOS**: tạo một file rỗng tên `DISABLE` trong thư mục `SenOS` trên thẻ.
- **Gỡ hẳn**: xóa thư mục `trimui` và `SenOS` trên thẻ (và đổi `trimui.bak` về tên cũ nếu có).
- **Hình bị xoay ngang/ngược**: Cài đặt → Màn hình & giao diện → Xoay màn hình, hoặc sửa
  `"rotate"` (0/90/180/270) trong `SenOS/config/settings.json`.
- **Nút bị nhận sai**: Cài đặt → Điều khiển → Gán lại nút.
- **Độ sáng, LED, WiFi, Bluetooth không ăn**: các lệnh phần cứng nằm trong `SenOS/scripts/hw.sh`,
  `wifi.sh` và `bt.sh`, sửa được bằng trình soạn văn bản mà không cần biên dịch lại.
- **Bluetooth không ghép được**: đưa thiết bị về chế độ ghép nối rồi quét lại. Nếu vẫn lỗi, dùng
  "Về giao diện gốc" để ghép ở giao diện TrimUI và gửi `SenOS/logs/senos.log` để được sửa.
- **Game không vào, không có tiếng, hình sai màu hoặc giật**: gửi `SenOS/logs/senplay.log`.
- **Cần hỗ trợ**: Cài đặt → Hệ thống → Xuất báo cáo chẩn đoán, rồi gửi file
  `SenOS/logs/diag.txt` cùng `SenOS/logs/senos.log` và `SenOS/logs/boot.log`.

## Cập nhật

Chép `senos-update.zip` vào gốc thẻ nhớ (hoặc gửi qua Truyền file) rồi khởi động lại.
Cài đặt và dữ liệu chơi trong `SenOS/config` và `SenOS/data` được giữ nguyên.

## Giấy phép thành phần đi kèm

- Phông chữ Inter — SIL Open Font License 1.1.
- Thư viện Go `golang.org/x/image`, `golang.org/x/text` — giấy phép BSD 3 điều khoản.
- Đọc file 7z: `github.com/bodgit/sevenzip`, `bodgit/plumbing`, `bodgit/windows`, `ulikunitz/xz`,
  `pierrec/lz4` (BSD 3 điều khoản); `klauspost/compress` (BSD/MIT/Apache-2.0); `andybalholm/brotli` (MIT);
  `hashicorp/golang-lru` (MPL-2.0); `spf13/afero`, `go4.org` (Apache-2.0).
- Danh sách chứng chỉ gốc (cacert.pem) của Mozilla — MPL 2.0.

- Các core giả lập trong `SenOS/cores/`: xem `SenOS/cores/NGUON-GOC.txt` và thư mục `licenses/`.
  Hai core (snes9x2005, Genesis Plus GX) chỉ cho phép phân phối phi thương mại: không bán gói này.

SenOS không kèm BIOS hay game nào.


## Mới ở 0.5.6

- **RetroArch — cài đặt** (thẻ Ứng dụng › Công cụ SenOS): mở thẳng menu RetroArch không cần chọn game,
  để chỉnh điều khiển, hình ảnh, âm thanh, tùy chọn core… Thoát RetroArch (Main Menu › Quit) là cài đặt
  tự được lưu.
- **Ngủ tiết kiệm pin hơn**:
  - Trước khi ngủ, SenOS tắt đèn LED, tắt WiFi và Bluetooth, chọn chế độ ngủ sâu; thức dậy tự bật lại
    và nối lại mạng/tai nghe. Tắt tính năng này ở Cài đặt › Pin & nguồn › “Tắt WiFi, Bluetooth khi ngủ”.
  - Nhấn nhanh nút nguồn **khi đang chơi game** giờ cũng cho máy ngủ thật (trước đây chỉ tắt màn hình,
    máy vẫn chạy nên tốn pin).
  - Máy kiểm tra để không “ngủ hụt” khi đang có sự kiện đánh thức; nếu hụt thì tự thử lại.

## Mới ở 0.5.7

- **Màn hình sạc**: cắm sạc khi đang ở menu SenOS là hiện màn hình theo dõi sạc: mức pin, thời gian còn
  lại để đầy, điện áp, dòng sạc, công suất, nhiệt độ pin (cảnh báo khi nóng). Trong lúc đó SenOS sạc tối ưu:
  CPU chạy chế độ tiết kiệm, màn hình tự tối sau 15 giây và tắt sau 45 giây, đèn LED báo mức pin
  (đỏ < 20%, vàng, xanh gần đầy, xanh sáng đứng khi đầy), và máy tự ngủ sau 3 phút để sạc mát và nhanh hơn.
  Bấm nút bất kỳ để bật lại màn hình, B để về menu; rút sạc là tự quay lại menu.
  Chỉnh ở Cài đặt › Pin & nguồn: “Màn hình sạc khi cắm sạc”, “Ngủ trong lúc sạc”, “Đèn LED báo mức pin khi sạc”.
- **NDS Advanced DraStic**: sửa lỗi lưu (save/savestate báo failed) và cheat không dùng được. Save,
  savestate và cheat giờ dùng chung với DraStic gốc của TrimUI, nên đổi qua lại hai core không mất save.
- **Ngủ**: nhấn nút nguồn là màn hình tắt ngay (trước đây phải chờ vài giây tắt WiFi/Bluetooth mới ngủ,
  dễ tưởng máy chưa nhận nút và bấm thêm lần nữa làm máy thức dậy); thức dậy luôn bật lại màn hình và độ sáng.

## Mới ở 0.5.8

- **Cập nhật qua mạng**: Cài đặt › Thông tin › **Kiểm tra cập nhật**. SenOS hỏi bản phát hành mới nhất trên
  GitHub (github.com/TrungTruong25/SenOS: file `update.json`, hoặc mục Releases), nếu có bản mới thì hiện ghi chú thay đổi và dung lượng; chọn
  “Tải & cài” là máy tải `senos-update.zip` về gốc thẻ (đứt mạng thì lần sau tải tiếp), kiểm tra file
  (mã SHA-256 và nội dung gói) rồi hỏi khởi động lại để cài. Game, save, cài đặt giữ nguyên.
- **Tự kiểm tra cập nhật** (bật sẵn): mỗi ngày một lần khi có WiFi; có bản mới thì hiện thông báo và dấu ●
  ở mục Kiểm tra cập nhật. Không bao giờ tự cài khi chưa hỏi.
- Cách cũ vẫn dùng được: chép `senos-update.zip` vào gốc thẻ → “Cài từ file trên thẻ”.

## Mới ở 0.5.10

- **Biểu tượng mới** cho hệ máy và công cụ: mỗi hệ máy có hình máy/tay cầm riêng trên nền màu riêng
  (GB, GBC, GBA, NDS, PSP, NES, SNES, Mega Drive, PS1, N64, Saturn, Dreamcast, arcade, PICO-8, Ports…).
  Ô trong Thư viện và Ứng dụng to hơn để biểu tượng rõ hơn. Ứng dụng trên thẻ có biểu tượng riêng thì giữ nguyên.

## Mới ở 0.5.11

- **NDS chỉ dùng DraStic gốc của TrimUI**: bỏ Advanced DraStic (nạp game chậm, lưu báo lỗi) và melonDS.
  Khi khởi động, SenOS tự xóa hai trình này khỏi thẻ, chuyển save/savestate còn trong Advanced DraStic sang
  DraStic gốc, trả `Emus/NDS/config.json` về bản gốc, bỏ các lựa chọn core đã lưu trỏ vào chúng, và tạo các
  thư mục `backup`, `savestates`, `cheats` mà DraStic gốc cần để lưu.

## Mới ở 0.5.13 (bản ổn định)

- **NDS**: dùng DraStic của TrimUI (bản "SDL2 MOD"). Bản mod này tự đặt khung hình theo màn 1280x720 nên ở chế độ
  một màn hình trên Brick Pro (1024x768) hình chỉ chiếm khoảng 3/4 màn, có viền. Đây là giới hạn của bản mod,
  không chỉnh được bằng cài đặt. Bỏ dòng `screen_scaling` mà 0.5.12 thêm (DraStic này không dùng).

## Mới ở 0.5.14

- **Dùng lại core gốc của RetroArch**: bỏ trình chạy game riêng của SenOS (senplay và các core đi kèm). Mọi hệ máy
  chạy bằng RetroArch với core gốc của TrimUI trên thẻ, theo cấu hình trong `Emus/<hệ máy>`. Khi khởi động, SenOS
  tự xóa `SenOS/emus`, `SenOS/cores`, `senplay` khỏi thẻ và đưa các game đã chọn chạy bằng “SenOS · …” về mặc định.
  Thẻ mới cần có bộ giả lập của TrimUI (Ứng dụng › Cài bộ giả lập của TrimUI, hoặc chép gói thẻ gốc).

## Mới ở 0.5.15

- **Cập nhật core RetroArch qua mạng**: RetroArch của TrimUI để trống địa chỉ tải core nên Online Updater báo
  “Failed to retrieve core list”. Kho core chính thức của libretro không có bản Linux ARM64, nên SenOS đặt địa chỉ
  kho core ARM64 của ArkOS (`christianhaitian/retroarch-cores`, khoảng 170 core). Online Updater › Core Downloader /
  Update Installed Cores dùng được (cần WiFi).
- Lần đầu mở **RetroArch — cài đặt**, SenOS **sao lưu toàn bộ core gốc** vào `RetroArch/.retroarch/cores-goc-trimui`
  (một lần, có thanh tiến độ; bản 0.5.15 chép ở nền lúc khởi động làm thẻ luôn bận, game NDS nạp chậm — đã sửa ở 0.5.16).
  Core cập nhật chạy lỗi thì vào Cài đặt › Thông tin › **Khôi phục core RetroArch gốc**.
- Nếu bạn tự đổi địa chỉ tải core hoặc ẩn lại Online Updater trong RetroArch, SenOS giữ nguyên lựa chọn đó.

## Mới ở 0.5.17

- **NDS một màn hình phủ kín màn hình**: SenOS tạo bản sao `Emus/NDS/drastic/libSDL2-brick.so` từ thư viện SDL2 mod
  của TrimUI (chỉ khi đúng bản đã kiểm tra), sửa 6 chỗ nhỏ chỉ áp dụng cho chế độ một màn hình (single): khung
  1024x768 thay vì 1280x720, ô game phủ kín, bỏ khung viền phủ lên, con trỏ bút đúng tỉ lệ. Hai màn hình và
  menu DraStic giữ nguyên như bản gốc. File gốc không bị đụng tới.
- Mặc định NDS chạy **“DraStic toàn màn hình (Brick Pro)”**; vẫn chọn được **“DraStic gốc của TrimUI”** cho cả hệ
  máy hoặc từng game (SELECT › Chạy bằng core). Nếu không tạo được bản chỉnh, mục toàn màn hình tự chạy như bản gốc.

## Mới ở 0.5.18

- **NDS toàn màn hình nét hơn**: phóng đúng 4 lần bằng điểm ảnh sắc nét thay vì làm mịn (trước bị mờ).
- **Âm lượng theo máy ngay khi vào game**: RetroArch, DraStic… đặt lại âm thanh to nhất khi mở; SenOS đặt lại mức
  âm lượng của máy vài lần trong vài giây đầu và sau khi máy thức dậy, không cần bấm nút âm lượng nữa.

## Mới ở 0.5.19 — màn hình sạc ổn định hơn

- Không mở chen ngang khi đang tải/cập nhật, đang Truyền file, đang có hộp thoại, bảng nhanh hay menu bên.
- Màn hình đang tối/tắt: nút bất kỳ (kể cả MENU, Home, âm lượng) chỉ bật lại màn hình, không vô tình mở menu
  hay đổi âm lượng khi không nhìn thấy.
- Vào game từ lúc đang ở màn hình sạc (qua menu bên/bảng nhanh): trả CPU về bình thường trước (trước đây game
  có thể chạy chậm vì CPU còn ở chế độ tiết kiệm).
- Thức dậy (tự ngủ khi sạc hoặc bấm nút nguồn) luôn bật lại màn hình đúng trạng thái; không còn hai lệnh ngủ chồng nhau.
- Bật lại màn hình đúng độ sáng đang dùng (kể cả độ sáng do firmware gốc đặt).
- Số liệu pin: bỏ qua nhiệt độ vô lý, hiểu cả đơn vị m°C, giới hạn % trong 0–100.

## Mới ở 0.5.22 — Quản lý file ngay trên máy

Thẻ **Ứng dụng › Quản lý file**: duyệt toàn bộ thẻ nhớ và sửa trực tiếp bằng nút bấm, không cần máy tính.

- **A** mở thư mục / mở file chữ để sửa · **B** lên thư mục cha (ở gốc thì thoát) · **L2/R2** lật trang.
- **X** thao tác với mục đang chọn: Sửa nội dung, Đổi tên, Chép, Cắt (di chuyển), Xóa (có hỏi lại), Thông tin.
- **Y** đánh dấu nhiều mục (hiện ngôi sao) → **X** để chép/cắt/xóa cả nhóm.
- Sau khi Chép/Cắt: mở thư mục đích, bấm **SELECT** để dán. Trùng tên thì chọn Ghi đè / Giữ cả hai / Bỏ qua.
- **START**: Thư mục mới, File chữ mới, Dán, Chọn tất cả.
- **Sửa file chữ** (.cfg, .ini, .json, .opt, .txt, .sh…): **A** sửa dòng bằng bàn phím trên màn hình, **Y** đảo nhanh giá trị true/false, on/off ở dòng đó, **X** thêm/xóa/nhân đôi dòng hoặc bật/tắt chú thích #, **SELECT** tìm chữ, **START** lưu. Thoát khi chưa lưu sẽ được hỏi.
- Được bảo vệ như trang web: không xóa/đổi tên/di chuyển thư mục hệ thống (Roms, Emus, RetroArch…), không ghi vào SenOS/bin, SenOS/scripts, trimui.

## Mới ở 0.5.21 — sửa file và thư mục trên thẻ từ trang Truyền file

- **Sửa file chữ:** nút **Sửa** hiện ở các file cấu hình/chữ (.cfg, .json, .ini, .opt, .sh, .txt, .cht, .m3u…, tối đa 1 MB). Mở trình soạn thảo ngay trên trình duyệt, **Ctrl+S** hoặc **Lưu** để ghi. Nếu file vừa bị máy đổi trong lúc bạn sửa, trang sẽ hỏi trước khi ghi đè. File game, ảnh, core không mở được để tránh hỏng.
- **File mới:** tạo file chữ trống trong thư mục đang mở.
- **Chọn nhiều:** tích ô ở đầu dòng (hoặc **Chọn tất cả**) → **Chép** / **Cắt** / **Xóa**. Sau khi Chép/Cắt, mở thư mục đích rồi bấm **Dán vào đây**. Trùng tên thì làm theo ô "Khi trùng tên" (Hỏi tôi = giữ cả hai).
- Không di chuyển được các thư mục hệ thống (Roms, Emus, RetroArch…) và không ghi vào phần lõi SenOS/bin, SenOS/scripts, trimui.

## Mới ở 0.5.20 — sửa treo máy khi thức dậy lúc đang sạc

- Ngủ thật (suspend) trong lúc cắm sạc làm Brick Pro treo ở màn hình sạc khi thức dậy rồi tự khởi động lại.
  Từ bản này **không bao giờ ngủ thật khi đang cắm sạc**:
  - Màn hình sạc: chỉ tối rồi tắt màn hình, CPU tiết kiệm (bỏ mục “Ngủ trong lúc sạc”).
  - Bấm nút nguồn khi đang cắm sạc (ở menu): **ngủ nhẹ** — tắt màn hình, đèn, CPU chạy chậm nhất; bấm nút bất kỳ
    là bật lại ngay. Rút sạc trong lúc ngủ nhẹ thì máy chuyển sang ngủ thật như bình thường.
  - Đang chơi game mà cắm sạc: nút nguồn không cho máy ngủ thật.
