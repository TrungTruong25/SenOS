#!/bin/sh
# Chạy một game bằng trình chạy riêng của SenOS (senplay) và core đi kèm.
#   play.sh <mã hệ máy> <tên core> <file game>
S=${SENOS_HOME:-/mnt/SDCARD/SenOS}
SD=${SENOS_SDCARD:-/mnt/SDCARD}
T=${SENOS_TMP:-/tmp}
ID=$1
CORE=$2
ROM=$3
CFG="$S/config/settings.json"
LOG="$S/logs/senplay.log"
mkdir -p "$S/logs" "$SD/Bios"
[ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 200000 ] && mv -f "$LOG" "$LOG.old"

# chạy bản sao trong RAM để rút thẻ hay cập nhật không làm treo game
BIN=$T/senplay
if ! cmp -s "$S/bin/senplay" "$BIN" 2> /dev/null; then
	cp "$S/bin/senplay" "$BIN" && chmod 755 "$BIN" || BIN="$S/bin/senplay"
fi

setting() { sed -n "s/.*\"$1\": *\"\{0,1\}\([^\",]*\)\"\{0,1\},\{0,1\}.*/\1/p" "$CFG" 2> /dev/null | head -n 1; }
LANG_UI=$(setting lang)
ROT=$(setting rotate)
BRIGHT=$(setting brightness)
RESUME=--resume
[ "$(setting resume_state)" = "false" ] && RESUME=

# core nặng: nếu người dùng chưa chọn hồ sơ CPU riêng thì cho chạy hết công suất trong lúc chơi
BOOST=
case "$CORE" in
melonds | pcsx_rearmed)
	case "$(setting cpu_profile)" in '' | stock) BOOST=1 ;; esac
	;;
esac

# game nén zip: giải ra RAM (trừ khi core tự đọc zip), tên file lưu vẫn theo tên file zip
NAME=$(basename "$ROM")
PLAY=$ROM
case "$ROM" in
*.zip | *.ZIP)
	rm -rf "$T/senos_rom"
	mkdir -p "$T/senos_rom"
	if unzip -o -q "$ROM" -d "$T/senos_rom" 2>> "$LOG"; then
		inner=$(ls -S "$T/senos_rom" | head -n 1)
		[ -n "$inner" ] && PLAY="$T/senos_rom/$inner"
	fi
	;;
esac

export LD_LIBRARY_PATH=/usr/trimui/lib:/usr/lib:/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
echo "== $(date '+%Y-%m-%d %H:%M:%S') $ID $CORE $NAME" >> "$LOG"
[ -n "$BOOST" ] && sh "$S/scripts/hw.sh" cpu performance
"$BIN" --core "$S/cores/${CORE}_libretro.so" --rom "$PLAY" --name "$NAME" \
	--sysdir "$SD/Bios" --savedir "$SD/Saves/SenOS/$ID" --statedir "$SD/Saves/SenOS/$ID/states" \
	--lang "${LANG_UI:-vi}" --rotate "${ROT:-0}" --brightness "${BRIGHT:-5}" \
	--keymap "$S/config/keymap.json" --hw "$S/scripts/hw.sh" --osd-file "$T/senos_osd" \
	--opts "$S/emus/$ID/core.opt" --opts-user "$S/config/cores/$CORE.opt" $RESUME \
	>> "$LOG" 2>&1
rc=$?
[ -n "$BOOST" ] && sh "$S/scripts/hw.sh" cpu menu
rm -rf "$T/senos_rom"
if [ "$rc" -ne 0 ]; then
	# để giao diện báo lý do cho người dùng khi quay lại
	{
		echo "rc=$rc"
		grep 'senplay:' "$LOG" | tail -n 2
	} > "$T/senos_play_error"
fi
exit 0
