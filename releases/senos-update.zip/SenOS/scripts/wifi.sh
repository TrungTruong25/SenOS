#!/bin/sh
# WiFi cho SenOS — dùng wpa_supplicant/wpa_cli có sẵn trong firmware gốc.
#   wifi.sh status | on | off | scan | connect <ssid> [mật khẩu]
#   wifi.sh boot [force]    gọi lúc bật máy: bật WiFi và nối lại mạng đã lưu (không làm gì nếu chưa lưu mạng nào)
#   wifi.sh keep [force]    gọi định kỳ khi đang mất mạng: bật lại / nối lại / xin lại địa chỉ IP
#   wifi.sh saved           in tên các mạng đã lưu, mỗi dòng một tên
#   wifi.sh connect-saved <ssid>   nối vào mạng đã lưu bằng mật khẩu đã lưu
#   wifi.sh forget <ssid>   quên một mạng đã lưu
export PATH=/usr/trimui/bin:$PATH
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH:-/usr/trimui/lib}
IF=wlan0
CONF=${SENOS_WIFI_CONF:-/etc/wifi/wpa_supplicant.conf}
# Bản sao danh sách mạng đã lưu, nằm trong bộ nhớ trong của máy (không nằm trên thẻ nhớ).
# Dùng khi wpa_supplicant của firmware không tự ghi lại được cấu hình.
STORE=${SENOS_WIFI_STORE:-/mnt/UDISK/senos-wifi.conf}
TAB=$(printf '\t')

ctrl_dir() {
	d=$(sed -n 's/^ctrl_interface=//p' "$CONF" 2> /dev/null | head -n 1 | sed 's/^DIR=//; s/ .*//')
	for c in "$d" /etc/wifi/sockets /var/run/wpa_supplicant; do
		[ -n "$c" ] && [ -e "$c/$IF" ] && { echo "$c"; return; }
	done
	echo "${d:-/etc/wifi/sockets}"
}
cli() { wpa_cli -p "$(ctrl_dir)" -i "$IF" "$@" 2> /dev/null; }
ip4() { ifconfig "$IF" 2> /dev/null | sed -n 's/.*inet addr:\([0-9.]*\).*/\1/p; s/.*inet \([0-9.]*\) .*/\1/p' | head -n 1; }
running() { pidof wpa_supplicant > /dev/null 2>&1; }

status() {
	if running; then echo "on=1"; else echo "on=0"; fi
	st=$(cli status)
	echo "state=$(echo "$st" | sed -n 's/^wpa_state=//p')"
	echo "ssid=$(echo "$st" | sed -n 's/^ssid=//p')"
	echo "ip=$(ip4)"
}

start() {
	running && return 0
	# 1) nhờ dịch vụ của firmware gốc bật (giữ đồng bộ với cài đặt gốc)
	mkdir -p /tmp/system
	: > /tmp/system/wifi_turn_on
	i=0
	while [ $i -lt 8 ] && ! running; do sleep 0.5; i=$((i + 1)); done
	running && return 0
	# 2) tự bật
	mkdir -p /etc/wifi/sockets
	if [ ! -f "$CONF" ]; then
		printf 'ctrl_interface=/etc/wifi/sockets\ndisable_scan_offload=1\nupdate_config=1\n\n' > "$CONF"
	fi
	ifconfig "$IF" up 2> /dev/null
	if [ -x /etc/init.d/wpa_supplicant ]; then
		/etc/init.d/wpa_supplicant start > /dev/null 2>&1
	else
		wpa_supplicant -B -i "$IF" -c "$CONF" > /dev/null 2>&1
	fi
	sleep 1
	pidof udhcpc > /dev/null 2>&1 || udhcpc -i "$IF" -b > /dev/null 2>&1
}

hexof() {
	h=$(printf '%s' "$1" | hexdump -v -e '/1 "%02x"' 2> /dev/null)
	[ -n "$h" ] || h=$(printf '%s' "$1" | od -An -v -tx1 2> /dev/null | tr -d ' \n')
	printf '%s' "$h"
}
state() { cli status | sed -n 's/^wpa_state=//p'; }
# số mạng mà wpa_supplicant đang nhớ
saved_count() { saved_ids | wc -l | tr -d ' '; }
# tên mạng (dạng hex) của mạng đã lưu số <id>; wpa_cli trả "tên" trong ngoặc kép hoặc hex sẵn
net_hex() {
	v=$(cli get_network "$1" ssid | tail -n 1)
	case "$v" in
	\"*\") v=${v#\"}; hexof "${v%\"}" ;;
	FAIL | '') ;;
	*) echo "$v" ;;
	esac
}
saved_ids() { cli list_networks | awk -F'\t' 'NR > 1 && $1 ~ /^[0-9]+$/ { print $1 }'; }
# số của mạng đã lưu có tên <ssid> (so theo byte nên tên có dấu tiếng Việt vẫn khớp)
saved_id() {
	want=$(hexof "$1")
	[ -n "$want" ] || return 0
	for i in $(saved_ids); do
		[ "$(net_hex "$i")" = "$want" ] && { echo "$i"; return 0; }
	done
}
# có mạng nào đã lưu (trong file cấu hình hoặc bản sao của SenOS) không
have_saved() {
	grep -q 'network={' "$CONF" 2> /dev/null && return 0
	[ -s "$STORE" ]
}
# ghi cấu hình xuống bộ nhớ trong để lần bật máy sau còn nhớ
persist() {
	cli set update_config 1 > /dev/null
	cli save_config > /dev/null
}
# bản sao của SenOS: mỗi dòng <tên mạng dạng hex> TAB <giá trị psk đúng như đưa cho wpa_cli> (rỗng = mạng mở)
store_put() { # store_put <hex> <psk>
	[ -n "$1" ] || return 0
	[ -d "$(dirname "$STORE")" ] || return 0
	{
		[ -f "$STORE" ] && grep -v "^$1$TAB" "$STORE" 2> /dev/null | grep -v "^$1\$"
		printf '%s\t%s\n' "$1" "$2"
	} > "$STORE.tmp" 2> /dev/null && mv -f "$STORE.tmp" "$STORE" 2> /dev/null
	chmod 600 "$STORE" 2> /dev/null
}
store_del() { # store_del <hex>
	[ -f "$STORE" ] || return 0
	grep -v "^$1$TAB" "$STORE" 2> /dev/null | grep -v "^$1\$" > "$STORE.tmp"
	mv -f "$STORE.tmp" "$STORE" 2> /dev/null
}
# wpa_supplicant không còn nhớ mạng nào nhưng SenOS có bản sao -> nạp lại
restore() {
	[ -s "$STORE" ] || return 0
	[ "$(saved_count)" = 0 ] || return 0
	while IFS="$TAB" read -r hex psk; do
		[ -n "$hex" ] || continue
		id=$(cli add_network | tail -n 1)
		case "$id" in '' | *[!0-9]*) continue ;; esac
		cli set_network "$id" ssid "$hex" > /dev/null
		if [ -n "$psk" ]; then
			cli set_network "$id" psk "$psk" > /dev/null
			cli set_network "$id" key_mgmt WPA-PSK > /dev/null
		else
			cli set_network "$id" key_mgmt NONE > /dev/null
		fi
		cli enable_network "$id" > /dev/null
	done < "$STORE"
	persist
}
# xin (lại) địa chỉ IP
dhcp() {
	if pidof udhcpc > /dev/null 2>&1; then
		killall -USR1 udhcpc 2> /dev/null
	else
		udhcpc -i "$IF" -b -t 12 > /dev/null 2>&1
	fi
}
# bật WiFi nếu đang tắt, nối lại mạng đã lưu, xin lại IP nếu đã nối mà chưa có địa chỉ
revive() { # revive <số lần thử bật>
	n=$1
	while ! running && [ "$n" -gt 0 ]; do
		start
		running && break
		n=$((n - 1))
		[ "$n" -gt 0 ] && sleep 3
	done
	running || return 1
	restore
	[ -n "$(ip4)" ] && return 0
	cli enable_network all > /dev/null
	case "$(state)" in
	COMPLETED) dhcp ;;
	SCANNING | ASSOCIATING | ASSOCIATED | 4WAY_HANDSHAKE | GROUP_HANDSHAKE | AUTHENTICATING) ;;
	*) cli reconnect > /dev/null ;;
	esac
	return 0
}

stop() {
	mkdir -p /tmp/system
	: > /tmp/system/wifi_turn_off
	sleep 1
	if running; then
		[ -x /etc/init.d/wpa_supplicant ] && /etc/init.d/wpa_supplicant stop > /dev/null 2>&1
		killall wpa_supplicant 2> /dev/null
	fi
	killall udhcpc 2> /dev/null
	ifconfig "$IF" down 2> /dev/null
}

wait_ip() {
	i=0
	while [ $i -lt "$1" ]; do
		[ -n "$(ip4)" ] && return 0
		sleep 1
		i=$((i + 1))
	done
	return 1
}

case "$1" in
status) status ;;
on)
	start
	wait_ip 8
	status
	;;
off)
	stop
	status
	;;
scan)
	start
	cli scan > /dev/null
	sleep 4
	# in ra: <tín hiệu dBm> TAB <cờ bảo mật> TAB <tên mạng>
	cli scan_results | awk -F'\t' 'NR > 1 && NF >= 5 { print $3 "\t" $4 "\t" $5 }'
	;;
connect)
	ssid=$2
	pass=$3
	start
	# dùng lại mạng đã lưu cùng tên nếu có
	id=$(saved_id "$ssid")
	[ -z "$id" ] && id=$(cli add_network | tail -n 1)
	case "$id" in '' | *[!0-9]*) echo "error=add_network"; status; exit 1 ;; esac
	# tên mạng gửi dạng hex để không vướng ký tự đặc biệt / tiếng Việt
	hex=$(hexof "$ssid")
	if [ -n "$hex" ]; then
		cli set_network "$id" ssid "$hex" > /dev/null
	else
		cli set_network "$id" ssid "\"$ssid\"" > /dev/null
	fi
	if [ -n "$pass" ]; then
		cli set_network "$id" psk "\"$pass\"" > /dev/null
		cli set_network "$id" key_mgmt WPA-PSK > /dev/null
	else
		cli set_network "$id" key_mgmt NONE > /dev/null
	fi
	cli select_network "$id" > /dev/null
	cli enable_network all > /dev/null
	persist
	killall udhcpc 2> /dev/null
	udhcpc -i "$IF" -b -t 12 > /dev/null 2>&1
	if wait_ip 20; then
		# nối được rồi mới ghi bản sao (mật khẩu sai thì không lưu)
		psk=
		if [ -n "$pass" ]; then
			psk=$(wpa_passphrase "$ssid" "$pass" 2> /dev/null | sed -n 's/^[[:space:]]*psk=//p' | tail -n 1)
			case "$psk" in
			[0-9a-f][0-9a-f][0-9a-f][0-9a-f]*) ;;
			*) psk="\"$pass\"" ;;
			esac
		fi
		store_put "$hex" "$psk"
	fi
	status
	;;
connect-saved)
	ssid=$2
	start
	restore
	id=$(saved_id "$ssid")
	case "$id" in '' | *[!0-9]*) echo "error=not_saved"; status; exit 1 ;; esac
	cli select_network "$id" > /dev/null
	cli enable_network all > /dev/null
	killall udhcpc 2> /dev/null
	udhcpc -i "$IF" -b -t 12 > /dev/null 2>&1
	wait_ip 20
	status
	;;
forget)
	ssid=$2
	store_del "$(hexof "$ssid")"
	if running; then
		id=$(saved_id "$ssid")
		case "$id" in '' | *[!0-9]*) ;; *)
			cli remove_network "$id" > /dev/null
			persist
			;;
		esac
	fi
	status
	;;
saved)
	if running; then
		# mỗi dòng: tên mạng dạng hex
		for i in $(saved_ids); do net_hex "$i"; echo; done | grep .
	fi
	;;
boot)
	# "force": người dùng đã bật WiFi trong SenOS -> bật kể cả khi không đọc được danh sách mạng đã lưu
	if have_saved || [ "$2" = force ]; then
		revive 3
		wait_ip 25
	fi
	status
	echo "saved=$(saved_count)"
	;;
keep)
	if have_saved || [ "$2" = force ]; then
		revive 1
		wait_ip 10
	fi
	status
	;;
*)
	echo "wifi.sh: lệnh không rõ: $1" >&2
	exit 2
	;;
esac
