#!/bin/sh
# Điều khiển phần cứng TrimUI Brick Pro (TG4040). Sửa trực tiếp file này nếu máy bạn khác.
#   hw.sh brightness 0..10 | volume 0..20 | led on <0-60> <RRGGBB> <hiệu ứng> <ms> | led off
#   hw.sh cpu stock|powersave|balanced|performance|menu | screen on|off | suspend | poweroff | reboot | hwclock
R=${SENOS_SYSROOT:-}
export PATH=/usr/trimui/bin:$PATH

# Chế độ thử trên máy tính (SENOS_SYSROOT khác rỗng): chỉ ghi lại lệnh, không đụng tới nguồn/âm thanh thật.
if [ -n "$R" ]; then
	echo "hw.sh $*" >> "$R/hw.log"
	case "$1" in suspend | poweroff | reboot | hwclock | volume) exit 0 ;; esac
fi

w() { # w <giá trị> <file>: ghi nếu file tồn tại
	[ -e "$R$2" ] && echo "$1" > "$R$2" 2> /dev/null
}

case "$1" in
brightness)
	lvl=${2:-5}
	set -- 3 8 16 28 44 64 90 122 160 205 255
	[ "$lvl" -lt 0 ] && lvl=0
	[ "$lvl" -gt 10 ] && lvl=10
	shift "$lvl"
	raw=$1
	D=$R/sys/kernel/debug/dispdbg
	if [ -d "$D" ]; then
		echo lcd0 > "$D/name"
		echo setbl > "$D/command"
		echo "$raw" > "$D/param"
		echo 1 > "$D/start"
	else
		for b in "$R"/sys/class/backlight/*/brightness; do
			[ -e "$b" ] && echo "$raw" > "$b"
		done
	fi
	;;
volume)
	lvl=${2:-10}
	[ "$lvl" -lt 0 ] && lvl=0
	[ "$lvl" -gt 20 ] && lvl=20
	# Cách của firmware gốc: hardwareservice đọc mức 0..20 từ /tmp/system/set_volume và đặt âm lượng
	# (loa, tai nghe, Bluetooth). Không có hardwareservice thì đặt thẳng bộ trộn âm.
	if pidof hardwareservice > /dev/null 2>&1; then
		mkdir -p /tmp/system
		echo "$lvl" > /tmp/system/set_volume
	elif amixer -c 0 sget 'Soft Volume Master' > /dev/null 2>&1; then
		amixer -c 0 sset 'Soft Volume Master' "$((lvl * 255 / 20))" > /dev/null 2>&1
	else
		if [ "$lvl" -le 0 ]; then v=63; else v=$((40 - lvl * 40 / 20)); fi
		amixer -c 0 sset 'digital volume' "$v" > /dev/null 2>&1
	fi
	;;
led)
	L=/sys/class/led_anim
	[ -d "$R$L" ] || exit 0
	if [ "$2" = "off" ]; then
		for f in max_scale max_scale_lr max_scale_f1f2 max_scale_rear; do w 0 $L/$f; done
		for z in m lr l r f1 f2 rear; do w 0 $L/effect_$z; done
		exit 0
	fi
	bri=${3:-24}; color=${4:-FFFFFF}; effect=${5:-4}; speed=${6:-1500}
	w 1 $L/effect_enable
	for f in max_scale max_scale_lr max_scale_f1f2 max_scale_rear; do w "$bri" $L/$f; done
	for z in m lr l r f1 f2 rear; do
		[ -e "$R$L/effect_$z" ] || continue
		w "$color " $L/effect_rgb_hex_$z
		w "$speed" $L/effect_duration_$z
		w -1 $L/effect_cycles_$z
		w "$effect" $L/effect_$z
	done
	;;
cpu)
	C=/sys/devices/system/cpu/cpu0/cpufreq
	case "$2" in
	powersave)   w ondemand $C/scaling_governor; w 408000 $C/scaling_min_freq; w 1416000 $C/scaling_max_freq ;;
	balanced)    w ondemand $C/scaling_governor; w 408000 $C/scaling_min_freq; w 1800000 $C/scaling_max_freq ;;
	performance) w 2000000 $C/scaling_max_freq; w performance $C/scaling_governor ;;
	menu)        w ondemand $C/scaling_governor; w 408000 $C/scaling_min_freq; w 2000000 $C/scaling_max_freq ;;
	*) : ;; # stock: không đụng tới
	esac
	;;
screen)
	# tắt/bật màn hình bằng đèn nền (an toàn hơn tắt LCD): screen off | screen on <mức 0..10>
	if [ "$2" = off ]; then
		D=$R/sys/kernel/debug/dispdbg
		if [ -d "$D" ]; then
			echo lcd0 > "$D/name"; echo setbl > "$D/command"; echo 0 > "$D/param"; echo 1 > "$D/start"
		else
			for b in "$R"/sys/class/backlight/*/brightness; do [ -e "$b" ] && echo 0 > "$b"; done
		fi
	else
		exec sh "$0" brightness "${3:-5}"
	fi
	;;
suspend)
	sync
	# ngủ sâu (deep) thay vì s2idle nếu nhân hỗ trợ: hao pin ít hơn hẳn
	if [ -e "$R/sys/power/mem_sleep" ] && grep -q deep "$R/sys/power/mem_sleep"; then
		echo deep > "$R/sys/power/mem_sleep" 2> /dev/null
	fi
	n=0
	while [ $n -lt 3 ]; do
		# giao thức wakeup_count: không ngủ hụt khi đang có sự kiện đánh thức dở dang
		c=$(cat "$R/sys/power/wakeup_count" 2> /dev/null)
		[ -n "$c" ] && echo "$c" > "$R/sys/power/wakeup_count" 2> /dev/null
		echo mem > "$R/sys/power/state" 2> /dev/null && exit 0
		n=$((n + 1))
		sleep 1
	done
	exit 1
	;;
poweroff)
	sync
	w 0 /sys/class/led_anim/max_scale
	poweroff
	sleep 8
	echo o > /proc/sysrq-trigger
	;;
reboot)
	sync
	reboot
	sleep 8
	echo b > /proc/sysrq-trigger
	;;
hwclock)
	hwclock -w -u 2> /dev/null
	;;
*)
	echo "hw.sh: lệnh không rõ: $1" >&2
	exit 2
	;;
esac
exit 0
