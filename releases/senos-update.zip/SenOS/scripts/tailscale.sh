#!/bin/sh
# Điều khiển tailscaled (Tailscale) cho SenOS.
#   tailscale.sh start | stop | running
# Cần: SENOS_HOME (thư mục SenOS trên thẻ). Tailscale nằm ở $SENOS_HOME/tailscale.
HOME_DIR="${SENOS_HOME:-/mnt/SDCARD/SenOS}"
TS="$HOME_DIR/tailscale"
SOCK=/tmp/tailscaled.sock
PIDF=/tmp/tailscaled.pid
LOG="$HOME_DIR/logs/tailscaled.log"

is_running() {
	[ -f "$PIDF" ] && kill -0 "$(cat "$PIDF" 2> /dev/null)" 2> /dev/null
}

case "$1" in
running)
	is_running && echo "running=1" || echo "running=0"
	;;
start)
	if is_running; then
		echo "running=1"
		exit 0
	fi
	[ -x "$TS/bin/tailscaled" ] || {
		echo "error=chưa cài"
		exit 1
	}
	if [ ! -e /dev/net/tun ]; then
		mkdir -p /dev/net 2> /dev/null
		mknod /dev/net/tun c 10 200 2> /dev/null
	fi
	mkdir -p "$TS/state" "$HOME_DIR/logs"
	[ "$(wc -c < "$LOG" 2> /dev/null || echo 0)" -gt 1048576 ] && mv -f "$LOG" "$LOG.old"
	rm -f "$SOCK"
	# setsid + nohup: tiếp tục chạy khi SenOS thoát để mở game
	setsid nohup "$TS/bin/tailscaled" --state="$TS/state/tailscaled.state" --socket="$SOCK" --tun=tailscale0 \
		> "$LOG" 2>&1 < /dev/null &
	echo $! > "$PIDF"
	i=0
	while [ $i -lt 40 ] && [ ! -S "$SOCK" ]; do
		is_running || break
		sleep 0.25
		i=$((i + 1))
	done
	if [ -S "$SOCK" ]; then
		echo "running=1"
	else
		echo "error=tailscaled không khởi động được"
		exit 1
	fi
	;;
stop)
	if [ -x "$TS/bin/tailscale" ] && [ -S "$SOCK" ]; then
		timeout 5 "$TS/bin/tailscale" --socket="$SOCK" down > /dev/null 2>&1
	fi
	if is_running; then
		kill "$(cat "$PIDF")" 2> /dev/null
		i=0
		while [ $i -lt 20 ] && is_running; do
			sleep 0.25
			i=$((i + 1))
		done
		is_running && kill -9 "$(cat "$PIDF")" 2> /dev/null
	fi
	rm -f "$PIDF" "$SOCK"
	[ -x "$TS/bin/tailscaled" ] && timeout 5 "$TS/bin/tailscaled" --cleanup > /dev/null 2>&1
	echo "running=0"
	;;
*)
	echo "dùng: $0 start|stop|running" >&2
	exit 2
	;;
esac
