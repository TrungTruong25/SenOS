#!/bin/sh
# Chạy một game hoặc ứng dụng. Được gọi qua /tmp/cmd_to_run.sh bởi vòng lặp của firmware gốc.
#   $1 = game|app   $2 = thư mục giả lập/ứng dụng   $3 = script chạy   $4 = file game   $5 = hồ sơ CPU
S=${SENOS_HOME:-/mnt/SDCARD/SenOS}
KIND=$1
DIR=$2
LAUNCH=$3
ROM=$4
PROFILE=${5:-stock}

export LD_LIBRARY_PATH=/usr/trimui/lib
export PATH=/usr/trimui/bin:$PATH

BIN=${SENOS_BIN:-/tmp/senos}
[ -x "$BIN" ] || BIN="$S/bin/senos"
mkdir -p "$S/logs"

"$BIN" guard >> "$S/logs/guard.log" 2>&1 &
GUARD=$!

sh "$S/scripts/hw.sh" cpu "$PROFILE"

# MainUI gốc chạy game từ /usr/trimui/bin; ứng dụng thì chạy từ thư mục của nó
if [ "$KIND" = "app" ]; then cd "$DIR"; else cd /usr/trimui/bin 2>/dev/null || cd "$DIR"; fi

chmod a+x "$LAUNCH" 2>/dev/null
if [ -x "$LAUNCH" ]; then RUN=""; else RUN="sh"; fi
if [ -n "$ROM" ]; then
	$RUN "$LAUNCH" "$ROM"
else
	$RUN "$LAUNCH"
fi

kill $GUARD 2> /dev/null
wait $GUARD 2> /dev/null
[ "$PROFILE" != "stock" ] && sh "$S/scripts/hw.sh" cpu menu
"$BIN" post-game >> "$S/logs/senos.log" 2>&1
sync
