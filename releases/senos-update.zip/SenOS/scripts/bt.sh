#!/bin/sh
# Bluetooth cho SenOS — dùng bluetoothd/bluetoothctl có sẵn trong firmware gốc.
#   bt.sh status                 on=0|1, connected=<tên>, audio=0|1
#   bt.sh on [audio] | off       bật/tắt sóng ("audio": chạy thêm bluealsa cho tai nghe)
#   bt.sh boot [audio]           bật rồi nối lại các thiết bị đã ghép (gọi lúc khởi động)
#   bt.sh scan | devices         mỗi dòng: <địa chỉ> TAB <đã ghép 0|1> TAB <đang nối 0|1> TAB <loại> TAB <tên>
#   bt.sh pair|connect|disconnect|forget <địa chỉ>     in "ok" hoặc "failed <lý do>"
#   bt.sh audio-route on|off     (thử nghiệm) chuyển âm thanh sang tai nghe đang nối
export PATH=/usr/trimui/bin:$PATH
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH:-/usr/trimui/lib}
SCAN_SECONDS=8
MARK="# senos-bluetooth-audio"
ASOUNDRC="${HOME:-/root}/.asoundrc"
OURS_ALSA=/tmp/senos_bluealsa

# BusyBox của firmware gốc không có lệnh timeout: tự giới hạn thời gian chạy.
bounded() { # bounded <giây> <lệnh...>
	_t=$1
	shift
	"$@" &
	_pid=$!
	(sleep "$_t"; kill "$_pid" 2> /dev/null) > /dev/null 2>&1 &
	_w=$!
	wait "$_pid" 2> /dev/null
	_rc=$?
	kill "$_w" 2> /dev/null
	return $_rc
}
btctl() { # btctl <giây> <tham số bluetoothctl...>
	_s=$1
	shift
	bounded "$_s" bluetoothctl "$@" 2>&1 < /dev/null
}
running() { pidof bluetoothd > /dev/null 2>&1; }
powered() { running && btctl 5 show | grep -q "Powered: yes"; }
valid_mac() {
	case "$1" in
	[0-9A-Fa-f][0-9A-Fa-f]:[0-9A-Fa-f][0-9A-Fa-f]:[0-9A-Fa-f][0-9A-Fa-f]:[0-9A-Fa-f][0-9A-Fa-f]:[0-9A-Fa-f][0-9A-Fa-f]:[0-9A-Fa-f][0-9A-Fa-f]) return 0 ;;
	esac
	return 1
}
bluez_error() {
	_e=$(printf '%s\n' "$1" | sed -n 's/.*org\.bluez\.Error\.\([A-Za-z.]*\).*/\1/p' | tail -n 1)
	echo "${_e:-no-answer}"
}

list_devices() {
	running || return 0
	btctl 5 devices | while read -r _kind mac name; do
		[ "$_kind" = "Device" ] || continue
		valid_mac "$mac" || continue
		# thiết bị chưa gửi tên hiện bằng chính địa chỉ viết với dấu gạch: bỏ qua
		case "$name" in '' | [0-9A-F][0-9A-F]-[0-9A-F][0-9A-F]-[0-9A-F][0-9A-F]-*) continue ;; esac
		info=$(btctl 5 info "$mac")
		paired=0
		connected=0
		case "$info" in *"Paired: yes"*) paired=1 ;; esac
		case "$info" in *"Connected: yes"*) connected=1 ;; esac
		icon=$(printf '%s\n' "$info" | sed -n 's/^[[:space:]]*Icon: //p' | head -n 1)
		printf '%s\t%s\t%s\t%s\t%s\n' "$mac" "$paired" "$connected" "${icon:-unknown}" "$name"
	done
}

audio_mac() { # địa chỉ tai nghe/loa đang nối, nếu có
	list_devices | awk -F'\t' '$3 == 1 && $4 ~ /^audio/ { print $1; exit }'
}
a2dp_ready() {
	command -v bluealsa-aplay > /dev/null 2>&1 || return 1
	bounded 3 bluealsa-aplay -L 2> /dev/null | grep -q 'PROFILE=a2dp'
}
start_bluealsa() {
	command -v bluealsa > /dev/null 2>&1 || return 0
	pidof bluealsa > /dev/null 2>&1 && return 0
	(cd / && exec bluealsa -p a2dp-source) < /dev/null > /dev/null 2>&1 &
	: > "$OURS_ALSA"
}
stop_bluealsa() { # chỉ dừng bluealsa do SenOS tự chạy
	[ -f "$OURS_ALSA" ] || return 0
	killall bluealsa 2> /dev/null
	rm -f "$OURS_ALSA"
}

# Âm thanh (thử nghiệm): ghi ~/.asoundrc trỏ sang tai nghe; file có dòng đánh dấu để gỡ được.
route_clear() {
	[ -f "$ASOUNDRC" ] && grep -q "$MARK" "$ASOUNDRC" && rm -f "$ASOUNDRC"
	return 0
}
route_apply() {
	mac=$(audio_mac)
	if [ -z "$mac" ]; then
		route_clear
		echo "audio=0"
		return 0
	fi
	if [ -f "$ASOUNDRC" ] && ! grep -q "$MARK" "$ASOUNDRC"; then
		echo "audio=foreign" # đã có .asoundrc của phần mềm khác: không đụng tới
		return 0
	fi
	_n=0
	until a2dp_ready; do
		_n=$((_n + 1))
		if [ "$_n" -gt 6 ]; then
			route_clear
			echo "audio=0"
			return 0
		fi
		sleep 1
	done
	cat > "$ASOUNDRC.tmp" << EOF
$MARK
pcm.!default {
    type plug
    slave.pcm {
        type bluealsa
        device "$mac"
        profile "a2dp"
        delay 64
    }
}
ctl.!default {
    type hw
    card 0
}
EOF
	mv "$ASOUNDRC.tmp" "$ASOUNDRC"
	echo "audio=1"
}

turn_on() {
	hciconfig hci0 up 2> /dev/null
	if ! running && [ -x /etc/bluetooth/bluetoothd ]; then
		(cd / && /etc/bluetooth/bluetoothd start) < /dev/null > /dev/null 2>&1
		_n=0
		while ! running && [ "$_n" -lt 5 ]; do
			sleep 1
			_n=$((_n + 1))
		done
		sleep 1
	fi
	running || return 1
	btctl 10 power on > /dev/null
	btctl 10 pairable on > /dev/null
	[ "$1" = "audio" ] && start_bluealsa
	return 0
}
turn_off() {
	route_clear
	running && btctl 5 power off > /dev/null
	stop_bluealsa
}
reconnect_trusted() {
	btctl 5 devices | while read -r _kind mac _; do
		[ "$_kind" = "Device" ] || continue
		valid_mac "$mac" || continue
		case "$(btctl 5 info "$mac")" in
		*"Paired: yes"*"Trusted: yes"*"Connected: no"*) btctl 15 connect "$mac" > /dev/null ;;
		esac
	done
}
status() {
	if powered; then
		echo "on=1"
		echo "connected=$(list_devices | awk -F'\t' '$3 == 1 { print $5; exit }')"
	else
		echo "on=0"
		echo "connected="
	fi
	if [ -f "$ASOUNDRC" ] && grep -q "$MARK" "$ASOUNDRC"; then echo "audio=1"; else echo "audio=0"; fi
}
need_mac() {
	if ! valid_mac "$1"; then
		echo "failed bad-address"
		exit 0
	fi
	if ! running; then
		echo "failed bluetooth-off"
		exit 0
	fi
}

case "$1" in
status) status ;;
on)
	turn_on "$2" || echo "error=radio"
	status
	;;
off)
	turn_off
	status
	;;
boot)
	turn_on "$2" || exit 0
	sleep 2
	reconnect_trusted
	[ "$2" = "audio" ] && route_apply > /dev/null
	;;
scan)
	running || exit 0
	bounded $((SCAN_SECONDS + 4)) bluetoothctl --timeout "$SCAN_SECONDS" scan on > /dev/null 2>&1 < /dev/null
	list_devices
	;;
devices) list_devices ;;
pair)
	need_mac "$2"
	case "$(btctl 5 info "$2")" in
	*"Paired: yes"*) ;;
	*)
		out=$(btctl 40 pair "$2")
		case "$out" in
		*"Pairing successful"* | *"AlreadyExists"*) ;;
		*)
			echo "failed pair-$(bluez_error "$out")"
			exit 0
			;;
		esac
		;;
	esac
	btctl 10 trust "$2" > /dev/null
	out=$(btctl 30 connect "$2")
	case "$out" in
	*"Connection successful"*) echo "ok" ;;
	*)
		# có thể thiết bị đang tự nối: chờ thêm một chút
		_n=0
		until btctl 5 info "$2" | grep -q "Connected: yes"; do
			_n=$((_n + 1))
			if [ "$_n" -gt 8 ]; then
				echo "failed connect-$(bluez_error "$out")"
				exit 0
			fi
			sleep 1
		done
		echo "ok"
		;;
	esac
	;;
connect)
	need_mac "$2"
	out=$(btctl 30 connect "$2")
	case "$out" in
	*"Connection successful"*) echo "ok" ;;
	*) if btctl 5 info "$2" | grep -q "Connected: yes"; then echo "ok"; else echo "failed connect-$(bluez_error "$out")"; fi ;;
	esac
	;;
disconnect)
	need_mac "$2"
	out=$(btctl 10 disconnect "$2")
	case "$out" in
	*"Successful disconnected"* | *"Disconnection successful"*) echo "ok" ;;
	*) echo "failed disconnect-$(bluez_error "$out")" ;;
	esac
	;;
forget)
	need_mac "$2"
	out=$(btctl 10 remove "$2")
	case "$out" in
	*"Device has been removed"*) echo "ok" ;;
	*) echo "failed forget-$(bluez_error "$out")" ;;
	esac
	;;
audio-route)
	if [ "$2" = "on" ]; then
		start_bluealsa
		route_apply
	else
		route_clear
		echo "audio=0"
	fi
	;;
*)
	echo "bt.sh: lệnh không rõ: $1" >&2
	exit 2
	;;
esac
exit 0
