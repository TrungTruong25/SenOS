#!/bin/sh
# Chạy một game bằng RetroArch trên thẻ với core được chọn riêng cho game đó.
#   racore.sh <tên core, ví dụ mgba> <file game>
SD=${SENOS_SDCARD:-/mnt/SDCARD}
RA_DIR=$SD/RetroArch
CORE=$1
ROM=$2
cd "$RA_DIR" || exit 1
HOME=$RA_DIR/ exec "$RA_DIR/ra64.trimui" -v -L "$RA_DIR/.retroarch/cores/${CORE}_libretro.so" "$ROM"
