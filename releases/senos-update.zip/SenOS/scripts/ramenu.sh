#!/bin/sh
# Mở RetroArch không kèm game (vào thẳng menu) để chỉnh cài đặt: điều khiển, video, âm thanh, core…
# Cài đặt được lưu khi thoát (config_save_on_exit trong retroarch.cfg).
SD=${SENOS_SDCARD:-/mnt/SDCARD}
RA_DIR=$SD/RetroArch
[ -x "$RA_DIR/ra64.trimui" ] || chmod +x "$RA_DIR/ra64.trimui" 2>/dev/null
cd "$RA_DIR" || exit 1
HOME=$RA_DIR/ exec "$RA_DIR/ra64.trimui" -v --menu
